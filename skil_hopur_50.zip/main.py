from b_UI.A_UI_manager import Manager_UI

def main():
    ui = Manager_UI()
    
    ui.main_menu()

if __name__ == "__main__" :
    main()








    #   3009907461
    #   2410876598

    # NA9228


    # 2410876598
    # 50